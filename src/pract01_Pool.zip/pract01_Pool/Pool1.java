package pract01_Pool;

public class Pool1 extends Pool {   //no kids alone
	int instructorSwimming = 0;
	int kidSwimming = 0;
	public void init(int ki, int cap)           {}
    public synchronized void kidSwims() throws InterruptedException{
    	while(instructorSwimming==0) {
    		log.waitingToSwim();
    		wait();
    	}
    	notifyAll();
    	log.swimming();
    	kidSwimming++;
    }
    public void kidRests() {
    	log.resting();
    	kidSwimming--;
    }
    public void instructorSwims() {
    	log.swimming();
    	instructorSwimming++;
    }
    public void instructorRests() throws InterruptedException {
    	if(instructorSwimming==1 && kidSwimming>0) wait();
    	log.resting();
    	instructorSwimming--;
    }
}
