package pract01_Pool;

public class Pool3 extends Pool{ //max capacity
    public void init(int ki, int cap)           {}
    public void kidSwims()      {log.swimming();}
    public void kidRests()      {log.resting(); }
    public void instructorSwims()   {log.swimming();}
    public void instructorRests()   {log.resting(); }
}
